using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour {



    //declare and initialize our variables

    private Rigidbody2D playerRigidbody;
    
    private AudioSource aSource;



    public float playerSpeed = 12.0f;
    public float playerJumpForce = 1.0f;

    private bool playerOnFloor = true;

    private int keyCollected = 0;
    public int sceneLevel = 0;

    
    // Start is called before the first frame update
    void Start() {

        //getting the rigidbody and audio components for reference 

        playerRigidbody = gameObject.GetComponent<Rigidbody2D>();
        aSource = gameObject.GetComponent<AudioSource>();
    }


    // Update is called once per frame
    void FixedUpdate() {


        //clamp the player in the game window
        Vector2 localPosition = transform.position;

        localPosition.x = Mathf.Clamp(transform.position.x, -6.2f, 6.2f);
        transform.position = localPosition;


        //Debug.DrawRay(transform.position, Vector2.down * 0.62f, Color.cyan);

        //Check to see if we are on the floor
        LayerMask groundMask = LayerMask.GetMask("Ground");
        RaycastHit2D raycastHit2D = Physics2D.Raycast(transform.position, Vector2.down, 0.62f, groundMask);
        
        if(raycastHit2D.collider != null) {

            Debug.Log("We are hitting something");
            playerOnFloor = true;
            playerRigidbody.gravityScale = 1.0f;

        }else{

            playerOnFloor = false;
        
        }

        //movement code

        if(Input.GetKey(KeyCode.A)){

                playerRigidbody.AddForce(Vector2.left * playerSpeed, ForceMode2D.Force);

        }
                
        if(Input.GetKey(KeyCode.D)){

                playerRigidbody.AddForce(Vector2.right * playerSpeed, ForceMode2D.Force);

        }


        //jumping code
        if(Input.GetKeyDown(KeyCode.Space) && playerOnFloor == true){

                playerRigidbody.AddForce(Vector2.up * playerJumpForce, ForceMode2D.Force);
                playerRigidbody.gravityScale = 2.4f;
                aSource.Play();
                
        }
        

    }

    public void OnCollisionEnter2D(Collision2D coll){



        //if we collect the key then we can proceed towards the lock, and "open" it to the next level
        if(coll.gameObject.tag == "Key"){

            Debug.Log("Collected the key!");
            coll.gameObject.SetActive(false);
            keyCollected = 1;
            Debug.Log("Key collected is now 1");

        }else if(keyCollected == 1 && coll.gameObject.tag == "Lock"){


                Debug.Log("Unlocked!!!");
                coll.gameObject.SetActive(false);
                SceneManager.LoadScene(sceneLevel);

            }
    }

}
