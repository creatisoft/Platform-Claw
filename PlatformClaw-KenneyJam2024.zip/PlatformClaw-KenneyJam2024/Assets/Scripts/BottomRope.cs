using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BottomRope : MonoBehaviour {
    // Start is called before the first frame update

   /* public void OnCollisionEnter2D(Collision2D coll){

        if(coll.gameObject.tag == "Platform" || coll.gameObject.tag == "Player"){

            Debug.Log("Touched Player from Rope");

            coll.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic;

            if(coll.transform.parent == null){

                coll.transform.parent = this.transform;

                //his.transform.parent = coll.transform;
                //this.transform.position = coll.transform.position;

            }
        }
    }*/
}
