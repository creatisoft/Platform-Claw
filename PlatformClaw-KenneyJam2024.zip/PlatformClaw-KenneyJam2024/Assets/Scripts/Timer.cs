using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {
    

        //an idea that was not implemented.
        
    
    public TextMeshProUGUI timerTextUI;
    public float gameTimer = 5.0f;
    
    // Start is called before the first frame update
    void Start() {

        timerTextUI.text = "Timer: 0.0";
        
    }

    // Update is called once per frame
    void Update() {
        
            //Debug.Log(5.0f - Time.time );
            
            timerTextUI.text = "Timer:" + (gameTimer - Time.time).ToString("0.00");

            if( (gameTimer - Time.time) <= 0.00f ){


                Debug.Log("Restart this game");


            }
            


    }
}
