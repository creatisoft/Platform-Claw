using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;

public class RopeScript : MonoBehaviour {


    public bool placeBlock = false;
    
    // Update is called once per frame
    void Update() {
        

        //clamping the claw position to not leave the window 
        //X and Y are clamped. 
        Vector2 localPosition = transform.position;
        localPosition.x = Mathf.Clamp(transform.position.x, -6.69f, 5.58f);
        localPosition.y = Mathf.Clamp(transform.position.y, 3.05f, 12.42f);
        transform.position = localPosition;

        //movement code below
        if(Input.GetKey(KeyCode.LeftArrow)){

            transform.Translate(Vector2.left * 4.8f * Time.deltaTime);

        }
                
        if(Input.GetKey(KeyCode.RightArrow)){


            transform.Translate(Vector2.right * 4.8f * Time.deltaTime);


        }

        if(Input.GetKey(KeyCode.UpArrow)){

            transform.Translate(Vector2.up * 4.8f * Time.deltaTime);

        }
                
        if(Input.GetKey(KeyCode.DownArrow)){


            transform.Translate(Vector2.down * 4.8f * Time.deltaTime);


        }


        if(Input.GetKeyDown(KeyCode.RightShift)){

            placeBlock = true;
            //this.transform.GetChild(20).parent = null;

            this.transform.GetChild(20).parent = null;
            
            placeBlock = true;


        }

    }

    public void OnCollisionEnter2D(Collision2D coll){

        //if we hit a platform let's pick it up, and set the parent to this, but also change the rigidbody2D type to static 
        //you can comment it out, and have some fun with it. 


        if(coll.gameObject.tag == "Platform"){

            Debug.Log("attached to the platform");
            if(coll.transform.parent == null){

                coll.gameObject.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
                coll.transform.parent = this.transform;

            }

        }


    }


}

    

