using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndZone : MonoBehaviour {

    public int loadLevel = 0;
    // Start is called before the first frame update


        //if the player falls into the water restart

    public void OnCollisionEnter2D(Collision2D coll){

        if(coll.gameObject.tag == "Player"){

            Debug.Log("Player is in the water");
            coll.gameObject.SetActive(false);
            SceneManager.LoadScene(loadLevel);

        }


    }
}
