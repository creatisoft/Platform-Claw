using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScenes : MonoBehaviour
{
    // This is the main menu with the play, and tutorial button. 

    public void LoadTutorial(){

        SceneManager.LoadScene(1);

    }

    public void PlayGame(){

        SceneManager.LoadScene(2);


    }

    // Update is called once per frame
}
