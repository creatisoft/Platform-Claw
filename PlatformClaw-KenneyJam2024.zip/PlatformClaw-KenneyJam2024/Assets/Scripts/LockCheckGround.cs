using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LockCheckGround : MonoBehaviour {
   



        //this was used to maker sure the lock was hitting a floor, and not water.
        //this isn't used.

    void Update() {
        


        //Debug.DrawRay(transform.position, Vector2.down * 0.80f, Color.cyan);

        LayerMask groundMask = LayerMask.GetMask("Ground");
        RaycastHit2D raycastHit2D = Physics2D.Raycast(transform.position, Vector2.down, 0.80f, groundMask);
        
        if(raycastHit2D.collider != null) {

            Debug.Log("The lock is hitting the floor!");
        }



    }
}
